package com.example.demo3;

public class Main {
    public static void main(String[] args) {
        AdultTicket adultTicket = new AdultTicket();
        ChildTicket childTicket = new ChildTicket();
        PensionerTicket pensionerTicket = new PensionerTicket();

        int totalCost = adultTicket.getPrice() * 9 + childTicket.getPrice() * 11 + pensionerTicket.getPrice() * 5;
        System.out.println("Общая стоимость билетов: " + totalCost + " монет");
    }
}
