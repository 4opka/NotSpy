package com.example.demo3;

public class ChildTicket extends Ticket {
    public ChildTicket() {
        super("Детский", 35);
    }
}
