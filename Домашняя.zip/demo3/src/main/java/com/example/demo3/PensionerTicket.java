package com.example.demo3;

public class PensionerTicket extends Ticket {
    public PensionerTicket() {
        super("Пенсионер", 49);
    }
}
