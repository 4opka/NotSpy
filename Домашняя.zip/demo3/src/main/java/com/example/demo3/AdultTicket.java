package com.example.demo3;

public class AdultTicket extends Ticket {
    public AdultTicket() {
        super("Взрослый", 70);
    }
}
